Write-Host "PSScriptRoot=$PSScriptRoot"
